namespace MyAlcohol
{
    public partial class PercentageCalculator : Form
    {
        public PercentageCalculator()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}