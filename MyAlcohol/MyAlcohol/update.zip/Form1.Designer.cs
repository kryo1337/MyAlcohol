﻿namespace MyAlcohol
{
    partial class PercentageCalculator
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbTypeOfGlass = new System.Windows.Forms.ComboBox();
            this.bResult = new System.Windows.Forms.Button();
            this.bClear = new System.Windows.Forms.Button();
            this.lTypeOfGlass = new System.Windows.Forms.Label();
            this.lPercentage = new System.Windows.Forms.Label();
            this.lNumberOfGlass = new System.Windows.Forms.Label();
            this.tbVolumeOfGlass = new System.Windows.Forms.TextBox();
            this.lVolumeOfGlass = new System.Windows.Forms.Label();
            this.lVolumeOfAlkohol = new System.Windows.Forms.Label();
            this.tbVolumeOfAlcohol = new System.Windows.Forms.TextBox();
            this.cbPercentage = new System.Windows.Forms.ComboBox();
            this.tbNumerOfGlass = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // cbTypeOfGlass
            // 
            this.cbTypeOfGlass.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.cbTypeOfGlass.FormattingEnabled = true;
            this.cbTypeOfGlass.Items.AddRange(new object[] {
            "Kieliszek (50 ml)",
            "Lampka (200 ml)",
            "Szklanka (250 ml)",
            "Duża Szklanka (350 ml)",
            "",
            ""});
            this.cbTypeOfGlass.Location = new System.Drawing.Point(14, 36);
            this.cbTypeOfGlass.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cbTypeOfGlass.Name = "cbTypeOfGlass";
            this.cbTypeOfGlass.Size = new System.Drawing.Size(178, 28);
            this.cbTypeOfGlass.TabIndex = 0;
            this.cbTypeOfGlass.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // bResult
            // 
            this.bResult.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.bResult.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bResult.Location = new System.Drawing.Point(14, 192);
            this.bResult.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bResult.Name = "bResult";
            this.bResult.Size = new System.Drawing.Size(86, 31);
            this.bResult.TabIndex = 1;
            this.bResult.Text = "Result";
            this.bResult.UseVisualStyleBackColor = false;
            this.bResult.Click += new System.EventHandler(this.bResult_Click);
            // 
            // bClear
            // 
            this.bClear.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.bClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bClear.Location = new System.Drawing.Point(102, 192);
            this.bClear.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bClear.Name = "bClear";
            this.bClear.Size = new System.Drawing.Size(86, 31);
            this.bClear.TabIndex = 2;
            this.bClear.Text = "Clear";
            this.bClear.UseVisualStyleBackColor = false;
            this.bClear.Click += new System.EventHandler(this.bClear_Click);
            // 
            // lTypeOfGlass
            // 
            this.lTypeOfGlass.AutoSize = true;
            this.lTypeOfGlass.Location = new System.Drawing.Point(71, 12);
            this.lTypeOfGlass.Name = "lTypeOfGlass";
            this.lTypeOfGlass.Size = new System.Drawing.Size(69, 20);
            this.lTypeOfGlass.TabIndex = 3;
            this.lTypeOfGlass.Text = "Naczynie";
            // 
            // lPercentage
            // 
            this.lPercentage.AutoSize = true;
            this.lPercentage.Location = new System.Drawing.Point(46, 71);
            this.lPercentage.Name = "lPercentage";
            this.lPercentage.Size = new System.Drawing.Size(116, 20);
            this.lPercentage.TabIndex = 4;
            this.lPercentage.Text = "Rodzaj alkoholu";
            // 
            // lNumberOfGlass
            // 
            this.lNumberOfGlass.AutoSize = true;
            this.lNumberOfGlass.Location = new System.Drawing.Point(59, 129);
            this.lNumberOfGlass.Name = "lNumberOfGlass";
            this.lNumberOfGlass.Size = new System.Drawing.Size(88, 20);
            this.lNumberOfGlass.TabIndex = 6;
            this.lNumberOfGlass.Text = "Ilość naczyń";
            // 
            // tbVolumeOfGlass
            // 
            this.tbVolumeOfGlass.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.tbVolumeOfGlass.Location = new System.Drawing.Point(14, 259);
            this.tbVolumeOfGlass.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbVolumeOfGlass.Name = "tbVolumeOfGlass";
            this.tbVolumeOfGlass.ReadOnly = true;
            this.tbVolumeOfGlass.Size = new System.Drawing.Size(173, 27);
            this.tbVolumeOfGlass.TabIndex = 8;
            this.tbVolumeOfGlass.TextChanged += new System.EventHandler(this.tbVolumeOfGlass_TextChanged);
            // 
            // lVolumeOfGlass
            // 
            this.lVolumeOfGlass.AutoSize = true;
            this.lVolumeOfGlass.Location = new System.Drawing.Point(46, 235);
            this.lVolumeOfGlass.Name = "lVolumeOfGlass";
            this.lVolumeOfGlass.Size = new System.Drawing.Size(118, 20);
            this.lVolumeOfGlass.TabIndex = 9;
            this.lVolumeOfGlass.Text = "Objetość napoju";
            // 
            // lVolumeOfAlkohol
            // 
            this.lVolumeOfAlkohol.AutoSize = true;
            this.lVolumeOfAlkohol.Location = new System.Drawing.Point(11, 293);
            this.lVolumeOfAlkohol.Name = "lVolumeOfAlkohol";
            this.lVolumeOfAlkohol.Size = new System.Drawing.Size(192, 20);
            this.lVolumeOfAlkohol.TabIndex = 10;
            this.lVolumeOfAlkohol.Text = "Objetość czystego spirytusu";
            // 
            // tbVolumeOfAlcohol
            // 
            this.tbVolumeOfAlcohol.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.tbVolumeOfAlcohol.Location = new System.Drawing.Point(14, 317);
            this.tbVolumeOfAlcohol.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbVolumeOfAlcohol.Name = "tbVolumeOfAlcohol";
            this.tbVolumeOfAlcohol.ReadOnly = true;
            this.tbVolumeOfAlcohol.Size = new System.Drawing.Size(173, 27);
            this.tbVolumeOfAlcohol.TabIndex = 11;
            // 
            // cbPercentage
            // 
            this.cbPercentage.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.cbPercentage.FormattingEnabled = true;
            this.cbPercentage.Items.AddRange(new object[] {
            "Piwo (6%)",
            "Wino (14%)",
            "Wódka (40%)",
            "Bimber (60%)"});
            this.cbPercentage.Location = new System.Drawing.Point(14, 94);
            this.cbPercentage.Name = "cbPercentage";
            this.cbPercentage.Size = new System.Drawing.Size(178, 28);
            this.cbPercentage.TabIndex = 12;
            // 
            // tbNumerOfGlass
            // 
            this.tbNumerOfGlass.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.tbNumerOfGlass.Location = new System.Drawing.Point(14, 153);
            this.tbNumerOfGlass.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbNumerOfGlass.Name = "tbNumerOfGlass";
            this.tbNumerOfGlass.Size = new System.Drawing.Size(178, 27);
            this.tbNumerOfGlass.TabIndex = 7;
            // 
            // PercentageCalculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumPurple;
            this.ClientSize = new System.Drawing.Size(201, 367);
            this.Controls.Add(this.cbPercentage);
            this.Controls.Add(this.tbVolumeOfAlcohol);
            this.Controls.Add(this.lVolumeOfAlkohol);
            this.Controls.Add(this.lVolumeOfGlass);
            this.Controls.Add(this.tbVolumeOfGlass);
            this.Controls.Add(this.tbNumerOfGlass);
            this.Controls.Add(this.lNumberOfGlass);
            this.Controls.Add(this.lPercentage);
            this.Controls.Add(this.lTypeOfGlass);
            this.Controls.Add(this.bClear);
            this.Controls.Add(this.bResult);
            this.Controls.Add(this.cbTypeOfGlass);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "PercentageCalculator";
            this.Text = "Percentage Calculator ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ComboBox cbTypeOfGlass;
        private Button bResult;
        private Button bClear;
        private Label lTypeOfGlass;
        private Label lPercentage;
        private Label lNumberOfGlass;
        private TextBox tbVolumeOfGlass;
        private Label lVolumeOfGlass;
        private Label lVolumeOfAlkohol;
        private TextBox tbVolumeOfAlcohol;
        private ComboBox cbPercentage;
        private TextBox tbNumerOfGlass;
    }
}