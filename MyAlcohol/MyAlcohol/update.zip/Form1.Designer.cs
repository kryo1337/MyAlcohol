﻿namespace MyAlcohol
{
    partial class PercentageCalculator
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbTypeOfGlass = new System.Windows.Forms.ComboBox();
            this.bResult = new System.Windows.Forms.Button();
            this.bClear = new System.Windows.Forms.Button();
            this.lTypeOfGlass = new System.Windows.Forms.Label();
            this.lPercentage = new System.Windows.Forms.Label();
            this.tbPercentage = new System.Windows.Forms.TextBox();
            this.lNumberOfGlass = new System.Windows.Forms.Label();
            this.tbNumerOfGlass = new System.Windows.Forms.TextBox();
            this.tbVolumeOfGlass = new System.Windows.Forms.TextBox();
            this.lVolumeOfGlass = new System.Windows.Forms.Label();
            this.lVolumeOfAlkohol = new System.Windows.Forms.Label();
            this.tbVolumeOfAlcohol = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // cbTypeOfGlass
            // 
            this.cbTypeOfGlass.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.cbTypeOfGlass.FormattingEnabled = true;
            this.cbTypeOfGlass.Items.AddRange(new object[] {
            "Kieliszek (50 ml)",
            "Lampka (200 ml)",
            "Szklanka (250 ml)",
            "Duża Szklanka (350 ml)",
            "",
            ""});
            this.cbTypeOfGlass.Location = new System.Drawing.Point(12, 27);
            this.cbTypeOfGlass.Name = "cbTypeOfGlass";
            this.cbTypeOfGlass.Size = new System.Drawing.Size(156, 23);
            this.cbTypeOfGlass.TabIndex = 0;
            this.cbTypeOfGlass.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // bResult
            // 
            this.bResult.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.bResult.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bResult.Location = new System.Drawing.Point(12, 144);
            this.bResult.Name = "bResult";
            this.bResult.Size = new System.Drawing.Size(75, 23);
            this.bResult.TabIndex = 1;
            this.bResult.Text = "Result";
            this.bResult.UseVisualStyleBackColor = false;
            this.bResult.Click += new System.EventHandler(this.bResult_Click);
            // 
            // bClear
            // 
            this.bClear.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.bClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bClear.Location = new System.Drawing.Point(89, 144);
            this.bClear.Name = "bClear";
            this.bClear.Size = new System.Drawing.Size(75, 23);
            this.bClear.TabIndex = 2;
            this.bClear.Text = "Clear";
            this.bClear.UseVisualStyleBackColor = false;
            // 
            // lTypeOfGlass
            // 
            this.lTypeOfGlass.AutoSize = true;
            this.lTypeOfGlass.Location = new System.Drawing.Point(62, 9);
            this.lTypeOfGlass.Name = "lTypeOfGlass";
            this.lTypeOfGlass.Size = new System.Drawing.Size(55, 15);
            this.lTypeOfGlass.TabIndex = 3;
            this.lTypeOfGlass.Text = "Naczynie";
            // 
            // lPercentage
            // 
            this.lPercentage.AutoSize = true;
            this.lPercentage.Location = new System.Drawing.Point(25, 53);
            this.lPercentage.Name = "lPercentage";
            this.lPercentage.Size = new System.Drawing.Size(127, 15);
            this.lPercentage.TabIndex = 4;
            this.lPercentage.Text = "Zawartosc procentowa";
            // 
            // tbPercentage
            // 
            this.tbPercentage.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.tbPercentage.Location = new System.Drawing.Point(12, 71);
            this.tbPercentage.Name = "tbPercentage";
            this.tbPercentage.Size = new System.Drawing.Size(156, 23);
            this.tbPercentage.TabIndex = 5;
            this.tbPercentage.TextChanged += new System.EventHandler(this.tbPercentage_TextChanged);
            // 
            // lNumberOfGlass
            // 
            this.lNumberOfGlass.AutoSize = true;
            this.lNumberOfGlass.Location = new System.Drawing.Point(52, 97);
            this.lNumberOfGlass.Name = "lNumberOfGlass";
            this.lNumberOfGlass.Size = new System.Drawing.Size(71, 15);
            this.lNumberOfGlass.TabIndex = 6;
            this.lNumberOfGlass.Text = "Ilosc naczyn";
            // 
            // tbNumerOfGlass
            // 
            this.tbNumerOfGlass.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.tbNumerOfGlass.Location = new System.Drawing.Point(12, 115);
            this.tbNumerOfGlass.Name = "tbNumerOfGlass";
            this.tbNumerOfGlass.Size = new System.Drawing.Size(156, 23);
            this.tbNumerOfGlass.TabIndex = 7;
            // 
            // tbVolumeOfGlass
            // 
            this.tbVolumeOfGlass.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.tbVolumeOfGlass.Location = new System.Drawing.Point(12, 194);
            this.tbVolumeOfGlass.Name = "tbVolumeOfGlass";
            this.tbVolumeOfGlass.Size = new System.Drawing.Size(152, 23);
            this.tbVolumeOfGlass.TabIndex = 8;
            this.tbVolumeOfGlass.TextChanged += new System.EventHandler(this.tbVolumeOfGlass_TextChanged);
            // 
            // lVolumeOfGlass
            // 
            this.lVolumeOfGlass.AutoSize = true;
            this.lVolumeOfGlass.Location = new System.Drawing.Point(40, 176);
            this.lVolumeOfGlass.Name = "lVolumeOfGlass";
            this.lVolumeOfGlass.Size = new System.Drawing.Size(94, 15);
            this.lVolumeOfGlass.TabIndex = 9;
            this.lVolumeOfGlass.Text = "Objetosc napoju";
            // 
            // lVolumeOfAlkohol
            // 
            this.lVolumeOfAlkohol.AutoSize = true;
            this.lVolumeOfAlkohol.Location = new System.Drawing.Point(10, 220);
            this.lVolumeOfAlkohol.Name = "lVolumeOfAlkohol";
            this.lVolumeOfAlkohol.Size = new System.Drawing.Size(154, 15);
            this.lVolumeOfAlkohol.TabIndex = 10;
            this.lVolumeOfAlkohol.Text = "Objetosc czystego spirytusu";
            // 
            // tbVolumeOfAlcohol
            // 
            this.tbVolumeOfAlcohol.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.tbVolumeOfAlcohol.Location = new System.Drawing.Point(12, 238);
            this.tbVolumeOfAlcohol.Name = "tbVolumeOfAlcohol";
            this.tbVolumeOfAlcohol.Size = new System.Drawing.Size(152, 23);
            this.tbVolumeOfAlcohol.TabIndex = 11;
            // 
            // PercentageCalculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumPurple;
            this.ClientSize = new System.Drawing.Size(176, 275);
            this.Controls.Add(this.tbVolumeOfAlcohol);
            this.Controls.Add(this.lVolumeOfAlkohol);
            this.Controls.Add(this.lVolumeOfGlass);
            this.Controls.Add(this.tbVolumeOfGlass);
            this.Controls.Add(this.tbNumerOfGlass);
            this.Controls.Add(this.lNumberOfGlass);
            this.Controls.Add(this.tbPercentage);
            this.Controls.Add(this.lPercentage);
            this.Controls.Add(this.lTypeOfGlass);
            this.Controls.Add(this.bClear);
            this.Controls.Add(this.bResult);
            this.Controls.Add(this.cbTypeOfGlass);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "PercentageCalculator";
            this.Text = "Percentage Calculator ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ComboBox cbTypeOfGlass;
        private Button bResult;
        private Button bClear;
        private Label lTypeOfGlass;
        private Label lPercentage;
        private TextBox tbPercentage;
        private Label lNumberOfGlass;
        private TextBox tbNumerOfGlass;
        private TextBox tbVolumeOfGlass;
        private Label lVolumeOfGlass;
        private Label lVolumeOfAlkohol;
        private TextBox tbVolumeOfAlcohol;
    }
}