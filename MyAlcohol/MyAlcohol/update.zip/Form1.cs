namespace MyAlcohol
{
    public partial class PercentageCalculator : Form
    {
        public PercentageCalculator()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void tbPercentage_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbVolumeOfGlass_TextChanged(object sender, EventArgs e)
        {

        }

        private void bResult_Click(object sender, EventArgs e)
        {
            try
            {
                string ml = "";
                for (int i = 0; i < (cbTypeOfGlass.Text).Length; i++)
                {
                    if (char.IsDigit((cbTypeOfGlass.Text)[i]))
                    {
                        ml += (cbTypeOfGlass.Text)[i];
                    }
                }

                string percentage = "";
                for (int i = 0; i < (cbPercentage.Text).Length; i++)
                {
                    if (char.IsDigit((cbPercentage.Text)[i]))
                    {
                        percentage += (cbPercentage.Text)[i];
                    }
                }
                double volumeOfGlass = Math.Round(float.Parse(ml) / 1000 * float.Parse(tbNumerOfGlass.Text), 3);
                double volumeOfAlcohol = Math.Round(volumeOfGlass * float.Parse(percentage) / 100, 3);
                tbVolumeOfGlass.Text = $"{volumeOfGlass} litra";
                tbVolumeOfAlcohol.Text = $"{volumeOfAlcohol} litra";
            }
            catch (System.FormatException)
            {
                MessageBox.Show("Wprowad� poprawnie dane!");
            }
        }

        private void bClear_Click(object sender, EventArgs e)
        {
            cbTypeOfGlass.Text = null;
            tbNumerOfGlass.Text = null;
            cbPercentage.Text = null;
            tbVolumeOfAlcohol.Text = null;
            tbVolumeOfGlass.Text = null;
        }
    }
}