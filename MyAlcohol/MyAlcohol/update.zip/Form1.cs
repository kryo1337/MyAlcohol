namespace MyAlcohol
{
    public partial class PercentageCalculator : Form
    {
        public PercentageCalculator()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void tbPercentage_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbVolumeOfGlass_TextChanged(object sender, EventArgs e)
        {

        }

        private void bResult_Click(object sender, EventArgs e)
        {
            string number = "";
            number = "";
            for (int i = 0; i < (cbTypeOfGlass.Text).Length; i++)
            {
                if (char.IsDigit((cbTypeOfGlass.Text)[i]))
                {
                    number += (cbTypeOfGlass.Text)[i];
                }
            }
            double volumeOfGlass = Math.Round(float.Parse(number)/1000, 3);
            float volumeOfAlcohol = float.Parse(number)/1000 * float.Parse(tbPercentage.Text)/100;
            tbVolumeOfGlass.Text = $"{volumeOfGlass} litra";
            tbVolumeOfAlcohol.Text = $"{volumeOfAlcohol} litra";
        }
    }
}